public class Relatorio {
    Entrevista e = new Entrevista();
    /*public int qntEntrevistadas() {
        return 0;
    }*/// qntEntrevistadas

    public double porcentagem1835(double totalEntrevistadas, double cont1835) {
        return ((cont1835*100)/totalEntrevistadas);
    }// porcentagem1835

    public double porcentagem40(double totalEntrevistadas, double cont40) {
        return ((cont40*100)/totalEntrevistadas);
    }// porcentagem40

}// Relatorio
