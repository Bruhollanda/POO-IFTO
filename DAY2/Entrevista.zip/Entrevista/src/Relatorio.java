public class Relatorio {
    /*public int qntEntrevistadas() {
        return 0;
    }*/// qntEntrevistadas

    public double porcentagemIdade1835(double totalEntrevistadas, double cont1835) {
        return ((cont1835*100)/totalEntrevistadas);
    }// porcentagem1835

    public double porcentagemIdade40(double totalEntrevistadas, double cont40) {
        return ((cont40*100)/totalEntrevistadas);
    }// porcentagem40

}// Relatorio
